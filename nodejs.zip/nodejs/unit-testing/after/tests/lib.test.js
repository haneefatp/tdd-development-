const lib = require('../lib');
const db = require('../db');
const mail = require('../mail');

describe('absolute', () => {
    it("should return a positive number when the input is positive ", () => {
        const result = lib.absolute(1);
        expect(result).toBe(1);
    });
    
    it("should return a positive number when the input is negetive ", () => {
        const result = lib.absolute(-1);
        expect(result).toBe(1);
    });
    
    it("should return 0 when the input is 0 ", () => {
        const result = lib.absolute(0);
        expect(result).toBe(0);
    });
});

describe('greet', () => {
    it('should return greeting message', () => {
        const result = lib.greet('Haneefa');
        // your test neither too specific nor too general
        expect(result).toBe('Welcome Haneefa');
        //expect(result).toContain('Haneefa');
    });
});

describe('getCurrencies', () => {
    it('should return currency from the list of currencies', () => {
        const result = lib.getCurrencies();
        //too generic
        expect(result).toBeDefined();
        expect(result).not.toBeNull();  
        
        //too specefic
        expect(result[0]).toBe('USD');
        expect(result[1]).toBe('AUD');
        expect(result[2]).toBe('EUR');
        expect(result.length).toBe(3);

        //proper way
        expect(result).toContain('USD');
        expect(result).toContain('AUD');
        expect(result).toContain('EUR');

        //ideal way
        expect(result).toEqual(expect.arrayContaining(['USD', 'AUD', 'EUR']));
    })
});

describe('getProduct', () => {
    it('should return product with given id', () => {
        const result = lib.getProduct(1);
        // too specefic
        // expect(result).toBe({id: 1, price: 10});
        // expect(result).toEqual({id: 1, price: 10});

        //proper way
        expect(result).toMatchObject({id: 1, price: 10});
    });
});

describe('registerUser', () => {
    it('should throw an error when the username is falsy', () => {
        const args = [null, undefined, '', 0, false];
        args.forEach( (a) => {
            expect(() => { lib.registerUser(a)  }).toThrow();
        });       
    });

    it('should return a user object when the username is valid', () => {
        const result = lib.registerUser('Haneefa');
        expect(result).toMatchObject({username: 'Haneefa'});
        expect(result.id).toBeLessThanOrEqual(new Date().getTime());
        //expect(result.id).toBeGreaterThan(0);
    });
});

describe('applyDiscount', () => {
    it('should apply 10% discount if the customer has more than 10 points', () => {
        db.getCustomerSync = function (customerId) {
            console.log('Fake reading customer...')
            return {id: customerId, points: 11};
        }

        const order = {customerId: 1, totalPrice: 20};
        lib.applyDiscount(order);
        expect(order.totalPrice).toBe(18);
    });
});

describe('notifyCustomer', () => {
    it('should send an email to customer', () => {        
        db.getCustomerSync = function(customerId) {
            return {id: customerId, email: 'testemail@test.com'}
        }

        let mailSent = false;
        mail.send = function(email, message) {
            mailSent = true;
        }
        lib.notifyCustomer({customerId: 1});
        expect(mailSent).toBe(true);
    });
});

describe('notifyCustomer - jest way', () => {
    it('should send an email to customer', () => {
        db.getCustomerSync = jest.fn().mockReturnValue({email: 'testemails@test.com'});
        mail.send = jest.fn();
        lib.notifyCustomer({customerId: 1});
        //more generic
        expect(mail.send).toHaveBeenCalled();
        // expect(mail.send).toHaveBeenCalledWith({email: 'testemail@test.com', message: '...'});
        expect(mail.send.mock.calls[0][0]).toBe('testemails@test.com');
        expect(mail.send.mock.calls[0][1]).toMatch(/order/);

        expect(db.getCustomerSync.mock.calls[0][0]).toBe(1);
    });
});
