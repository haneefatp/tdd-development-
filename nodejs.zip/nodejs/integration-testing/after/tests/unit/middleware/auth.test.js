const {User} = require('../../../models/user');
const auth = require('../../../middleware/auth');
const mongoose = require('mongoose');

describe('auth middleware', () => {
  it('should populate req.user with the payload of a valid JWT', () => {
    // a valid user object
    const user = { 
      _id: mongoose.Types.ObjectId().toHexString(), // to understant the id to mongoose model
      isAdmin: true 
    };
    const token = new User(user).generateAuthToken();
    // mock request object
    const req = {
      header: jest.fn().mockReturnValue(token)
    };
    // initialise as `res` should be passed as an argument
    const res = {};
    // mock next funtion
    const next = jest.fn();
    
    auth(req, res, next);
    expect(req.user).toBeDefined();
    expect(req.user).toMatchObject(user);
  });
});