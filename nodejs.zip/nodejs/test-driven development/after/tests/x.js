// POST api/rental {customer, movie}

// return 401 if the user is not logged in
// return 400 if there is no valid customeId provided
// return 400 if there is no valid movieId provided
// return 404 if there is no stock available.
// return 400 if there is a valid rental exist for the customer/movie
// return 200 when a valid rental saved
// add date out as today while saving a rental
// update the stock information
// update rental by adding the returned date
// calculate rental fee 



