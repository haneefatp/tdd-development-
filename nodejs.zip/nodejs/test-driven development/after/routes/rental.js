const Joi = require('joi');
const validate = require('../middleware/validate');
const {Rental} = require('../models/rental');
const {Customer} = require('../models/customer');
const {Movie} = require('../models/movie');
const auth = require('../middleware/auth');
const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

router.post('/', async (req, res) => {
    if(!req.headers['x-auth-token'])
        res.status(401).send('Unauthorized request');

    if (!mongoose.Types.ObjectId.isValid(req.body.customerId))
        res.status(400).send('Invalid Customer ID.');

    const customer = await Customer.findById(req.body.customerId);
    if(!customer) 
        res.status(400).send('Invalid customer provided');

    if (!mongoose.Types.ObjectId.isValid(req.body.movieId))
        res.status(400).send('Invalid Movie ID.'); 

    const movie = await Movie.findById(req.body.movieId);
    if(!movie) 
        res.status(400).send('Invalid movie provided');

    if(movie.numberInStock === 0)
        res.status(400).send('Movie is out of stock');

    const existingRental = await Rental.collection.findOne({
        customerId: req.body.customerId,
        movieId: req.body.movieId        
    });
    if(existingRental) 
        res.status(400).send('Rental already exist'); 
    res.status(200).send('Rental created!');   
});

module.exports = router;
